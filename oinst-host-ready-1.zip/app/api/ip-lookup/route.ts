import { type NextRequest, NextResponse } from 'next/server'

// Valida IPv4 ou IPv6 de forma simples
function isValidIp(ip: string): boolean {
  const ipv4 =
    /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/
  const ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:)$/
  return ipv4.test(ip) || ipv6.test(ip)
}

export async function GET(request: NextRequest) {
  const query = request.nextUrl.searchParams.get('ip')?.trim() ?? ''

  // Sem query = consulta o IP de origem da requisição
  if (query && !isValidIp(query)) {
    return NextResponse.json(
      { success: false, message: 'Endereço de IP inválido. Use IPv4 ou IPv6.' },
      { status: 400 },
    )
  }

  try {
    // ipwho.is: gratuito, HTTPS, sem necessidade de chave de API
    const endpoint = query
      ? `https://ipwho.is/${encodeURIComponent(query)}`
      : 'https://ipwho.is/'

    const res = await fetch(endpoint, {
      headers: { Accept: 'application/json' },
      // Evita cache para refletir dados atuais
      cache: 'no-store',
    })

    if (!res.ok) {
      throw new Error(`Serviço retornou status ${res.status}`)
    }

    const data = await res.json()

    if (!data.success) {
      return NextResponse.json(
        {
          success: false,
          message: data.message ?? 'Não foi possível localizar este IP.',
        },
        { status: 404 },
      )
    }

    return NextResponse.json({
      success: true,
      ip: data.ip,
      type: data.type,
      continent: data.continent,
      country: data.country,
      countryCode: data.country_code,
      region: data.region,
      city: data.city,
      latitude: data.latitude,
      longitude: data.longitude,
      postal: data.postal,
      callingCode: data.calling_code,
      flag: data.flag?.emoji ?? null,
      connection: {
        asn: data.connection?.asn ?? null,
        org: data.connection?.org ?? null,
        isp: data.connection?.isp ?? null,
        domain: data.connection?.domain ?? null,
      },
      timezone: {
        id: data.timezone?.id ?? null,
        utc: data.timezone?.utc ?? null,
        currentTime: data.timezone?.current_time ?? null,
      },
    })
  } catch (error) {
    console.log('[v0] Erro na pesquisa de IP:', (error as Error).message)
    return NextResponse.json(
      {
        success: false,
        message: 'Falha ao consultar o serviço de inteligência. Tente novamente.',
      },
      { status: 502 },
    )
  }
}
