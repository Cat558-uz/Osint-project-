import { NextRequest, NextResponse } from 'next/server'

const PLATFORMS = [
  { name: 'GitHub', url: 'https://github.com/' },
  { name: 'X / Twitter', url: 'https://x.com/' },
  { name: 'Instagram', url: 'https://www.instagram.com/' },
  { name: 'Reddit', url: 'https://www.reddit.com/user/' },
  { name: 'TikTok', url: 'https://www.tiktok.com/@' },
  { name: 'Twitch', url: 'https://www.twitch.tv/' },
  { name: 'LinkedIn', url: 'https://www.linkedin.com/in/' },
  { name: 'Telegram', url: 'https://t.me/' },
]

export async function GET(request: NextRequest) {
  const username = request.nextUrl.searchParams.get('username')?.trim().replace(/^@/, '') ?? ''
  if (!/^[a-zA-Z0-9._-]{2,40}$/.test(username)) {
    return NextResponse.json({ success: false, message: 'Username inválido. Use 2–40 caracteres alfanuméricos.' }, { status: 400 })
  }

  const results = await Promise.all(PLATFORMS.map(async (platform) => {
    const url = `${platform.url}${encodeURIComponent(username)}`
    try {
      const response = await fetch(url, { method: 'HEAD', redirect: 'manual', cache: 'no-store', signal: AbortSignal.timeout(7000) })
      const found = response.status >= 200 && response.status < 300
      return { ...platform, url, status: found ? 'encontrado' : 'não encontrado', httpStatus: response.status }
    } catch {
      return { ...platform, url, status: 'indisponível', httpStatus: 0 }
    }
  }))

  return NextResponse.json({ success: true, username, results })
}
