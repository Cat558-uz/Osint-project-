import { NextRequest, NextResponse } from 'next/server'

const ABSTRACT_API_KEY = process.env.ABSTRACT_API_KEY

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const type = String(body.type ?? '')
    const value = String(body.value ?? '').trim()

    if (!value || !['email', 'phone'].includes(type)) {
      return NextResponse.json({ success: false, message: 'Tipo ou valor inválido.' }, { status: 400 })
    }

    if (!ABSTRACT_API_KEY) {
      return NextResponse.json({ success: false, message: 'Provedor de verificação não configurado.' }, { status: 503 })
    }

    const base = type === 'email'
      ? 'https://emailvalidation.abstractapi.com/v1/'
      : 'https://phonevalidation.abstractapi.com/v1/'
    const parameter = type === 'email' ? 'email' : 'phone'
    const url = `${base}?api_key=${encodeURIComponent(ABSTRACT_API_KEY)}&${parameter}=${encodeURIComponent(value)}`
    const response = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(10000) })
    const data = await response.json()

    if (!response.ok) {
      return NextResponse.json({ success: false, message: data.error?.message ?? 'O provedor recusou a consulta.' }, { status: response.status })
    }

    return NextResponse.json({ success: true, type, data })
  } catch (error) {
    console.log('[v0] Falha no check:', (error as Error).message)
    return NextResponse.json({ success: false, message: 'Não foi possível concluir a consulta.' }, { status: 502 })
  }
}
