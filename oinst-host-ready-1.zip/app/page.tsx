import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { OsintWorkbench } from '@/components/osint-workbench'
import { Features } from '@/components/features'
import { Contact } from '@/components/contact'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main className="flex-1">
        <Hero />
        <OsintWorkbench />
        <Features />
        <Contact />
      </main>
      <SiteFooter />
    </div>
  )
}
