import type { Metadata, Viewport } from 'next'
import { JetBrains_Mono } from 'next/font/google'
import './globals.css'

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono-terminal',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'NODE//OSINT — Terminal de Inteligência de IP',
  description:
    'Ferramenta OSINT de pesquisa de IP em tempo real: geolocalização, provedor, ASN e informações de rede.',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0a140f',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={`dark bg-background ${jetbrainsMono.variable}`}>
      <body className="font-mono antialiased">
        {children}
      </body>
    </html>
  )
}
