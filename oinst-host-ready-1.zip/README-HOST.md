# OINST

Projeto Next.js preparado para hospedagem Node.js fora da Vercel.

## Requisitos
- Node.js 20.9+ (recomendado Node.js 22)
- npm

## Instalação
```bash
npm install
```

## Desenvolvimento
```bash
npm run dev
```

## Produção
```bash
npm run build
npm start
```

Por padrão, o Next.js inicia na porta 3000. A hospedagem pode definir a variável PORT.

## Variável opcional
A rota `/api/check` usa:
```env
ABSTRACT_API_KEY=sua_chave
```

Sem essa variável, a consulta de email/telefone retorna que o provedor não está configurado.

## Importante
Não coloque chaves de API diretamente no código. Use as variáveis de ambiente da hospedagem.
