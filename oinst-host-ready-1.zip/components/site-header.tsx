import { Button } from '@/components/ui/button'
import { Terminal } from 'lucide-react'

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4 md:px-6">
        <a href="#top" className="flex items-center gap-2 text-glow">
          <Terminal className="size-5 text-primary" aria-hidden="true" />
          <span className="text-sm font-bold tracking-widest text-primary">
            NODE<span className="text-accent">//</span>OSINT
          </span>
        </a>

        <nav className="flex items-center gap-1 md:gap-4">
          <a
            href="#ferramenta"
            className="hidden px-2 text-xs tracking-wider text-muted-foreground transition-colors hover:text-primary sm:inline-block"
          >
            $ ferramenta
          </a>
          <a
            href="#recursos"
            className="hidden px-2 text-xs tracking-wider text-muted-foreground transition-colors hover:text-primary sm:inline-block"
          >
            $ recursos
          </a>
          <Button
            size="sm"
            nativeButton={false}
            render={<a href="#contato" />}
            className="tracking-wider"
          >
            ./contato
          </Button>
        </nav>
      </div>
    </header>
  )
}
