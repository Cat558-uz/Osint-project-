'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Search,
  MapPin,
  Building2,
  Network,
  Clock,
  Globe,
  Loader2,
  TriangleAlert,
} from 'lucide-react'

type IpResult = {
  success: boolean
  ip?: string
  type?: string
  continent?: string
  country?: string
  countryCode?: string
  region?: string
  city?: string
  latitude?: number
  longitude?: number
  postal?: string
  callingCode?: string
  flag?: string | null
  connection?: {
    asn?: number | null
    org?: string | null
    isp?: string | null
    domain?: string | null
  }
  timezone?: {
    id?: string | null
    utc?: string | null
    currentTime?: string | null
  }
  message?: string
}

function Field({
  label,
  value,
}: {
  label: string
  value: string | number | null | undefined
}) {
  return (
    <div className="flex flex-col gap-1 border-b border-border/60 py-2">
      <span className="text-[0.7rem] uppercase tracking-widest text-muted-foreground">
        {label}
      </span>
      <span className="break-all text-sm text-foreground">
        {value !== null && value !== undefined && value !== ''
          ? String(value)
          : '—'}
      </span>
    </div>
  )
}

export function IpLookup() {
  const [ip, setIp] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<IpResult | null>(null)

  async function runLookup(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const params = ip.trim() ? `?ip=${encodeURIComponent(ip.trim())}` : ''
      const res = await fetch(`/api/ip-lookup${params}`)
      const data: IpResult = await res.json()

      if (!res.ok || !data.success) {
        setError(data.message ?? 'Não foi possível concluir a consulta.')
        return
      }
      setResult(data)
    } catch {
      setError('Erro de conexão. Verifique sua rede e tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="py-2">
      <div className="mb-8">
        <p className="mb-2 text-xs tracking-widest text-accent">
          // MÓDULO 01
        </p>
        <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
          Pesquisa de IP
        </h2>
        <p className="mt-2 max-w-lg leading-relaxed text-muted-foreground">
          Digite um endereço IPv4 ou IPv6. Deixe em branco para analisar o seu
          próprio endereço detectado pelo servidor.
        </p>
      </div>

      <form
        onSubmit={runLookup}
        className="flex flex-col gap-3 rounded-md border border-border bg-card/60 p-3 sm:flex-row sm:items-center"
      >
        <div className="flex flex-1 items-center gap-2 rounded-sm border border-border bg-background px-3">
          <span className="text-primary" aria-hidden="true">
            $
          </span>
          <input
            value={ip}
            onChange={(e) => setIp(e.target.value)}
            placeholder="ex.: 8.8.8.8  (ou vazio p/ seu IP)"
            aria-label="Endereço de IP para consultar"
            inputMode="text"
            autoComplete="off"
            spellCheck={false}
            className="h-10 w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/60"
          />
        </div>
        <Button
          type="submit"
          size="lg"
          disabled={loading}
          className="tracking-wider"
        >
          {loading ? (
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
          ) : (
            <Search className="size-4" aria-hidden="true" />
          )}
          {loading ? 'Consultando' : 'Executar'}
        </Button>
      </form>

      {error && (
        <div
          role="alert"
          className="mt-4 flex items-center gap-2 rounded-sm border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive"
        >
          <TriangleAlert className="size-4 shrink-0" aria-hidden="true" />
          {error}
        </div>
      )}

      {result && (
        <div className="mt-6 overflow-hidden rounded-md border border-border bg-card/60">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border bg-secondary/40 px-4 py-3">
            <div className="flex items-center gap-2">
              <span className="text-lg" aria-hidden="true">
                {result.flag ?? '🌐'}
              </span>
              <span className="text-sm font-bold tracking-wider text-primary text-glow">
                {result.ip}
              </span>
              {result.type && (
                <span className="rounded-sm border border-border px-1.5 py-0.5 text-[0.65rem] uppercase text-muted-foreground">
                  {result.type}
                </span>
              )}
            </div>
            {result.timezone?.currentTime && (
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Clock className="size-3.5" aria-hidden="true" />
                {new Date(result.timezone.currentTime).toLocaleTimeString(
                  'pt-BR',
                )}
              </span>
            )}
          </div>

          <div className="grid gap-x-8 gap-y-0 p-4 sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <p className="mb-1 flex items-center gap-1.5 text-xs font-semibold tracking-widest text-accent">
                <MapPin className="size-3.5" aria-hidden="true" />
                LOCALIZAÇÃO
              </p>
              <Field label="País" value={result.country} />
              <Field label="Região" value={result.region} />
              <Field label="Cidade" value={result.city} />
              <Field label="CEP / Postal" value={result.postal} />
            </div>

            <div>
              <p className="mb-1 flex items-center gap-1.5 text-xs font-semibold tracking-widest text-accent">
                <Building2 className="size-3.5" aria-hidden="true" />
                PROVEDOR
              </p>
              <Field label="ISP" value={result.connection?.isp} />
              <Field label="Organização" value={result.connection?.org} />
              <Field label="Domínio" value={result.connection?.domain} />
              <Field
                label="ASN"
                value={
                  result.connection?.asn ? `AS${result.connection.asn}` : null
                }
              />
            </div>

            <div>
              <p className="mb-1 flex items-center gap-1.5 text-xs font-semibold tracking-widest text-accent">
                <Network className="size-3.5" aria-hidden="true" />
                REDE & GEO
              </p>
              <Field label="Continente" value={result.continent} />
              <Field
                label="Coordenadas"
                value={
                  result.latitude != null && result.longitude != null
                    ? `${result.latitude}, ${result.longitude}`
                    : null
                }
              />
              <Field label="Fuso horário" value={result.timezone?.id} />
              <Field label="UTC" value={result.timezone?.utc} />
            </div>
          </div>

          {result.latitude != null && result.longitude != null && (
            <div className="border-t border-border p-4">
              <a
                href={`https://www.openstreetmap.org/?mlat=${result.latitude}&mlon=${result.longitude}#map=11/${result.latitude}/${result.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs tracking-wider text-primary underline-offset-4 hover:underline"
              >
                <Globe className="size-3.5" aria-hidden="true" />
                Abrir coordenadas no mapa
              </a>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
