import { Button } from '@/components/ui/button'
import { ShieldCheck, ArrowDown } from 'lucide-react'

export function Hero() {
  return (
    <section
      id="top"
      className="scanlines relative overflow-hidden cyber-grid"
    >
      {/* brilho radial de topo */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-64 bg-gradient-to-b from-primary/10 to-transparent"
        aria-hidden="true"
      />

      <div className="relative mx-auto grid max-w-6xl gap-10 px-4 py-16 md:grid-cols-2 md:items-center md:px-6 md:py-24">
        <div>
          <div className="mb-5 inline-flex items-center gap-2 rounded-sm border border-border bg-card/60 px-3 py-1 text-xs tracking-wider text-muted-foreground">
            <span className="size-2 animate-pulse rounded-full bg-primary" />
            SISTEMA ONLINE // v1.0
          </div>

          <h1 className="text-balance text-4xl font-bold leading-tight tracking-tight text-foreground text-glow md:text-5xl">
            Inteligência de rede
            <br />
            <span className="text-primary cursor-blink">em tempo real</span>
          </h1>

          <p className="mt-5 max-w-md text-pretty leading-relaxed text-muted-foreground">
            Uma plataforma OSINT enxuta e direta ao ponto. Consulte qualquer
            endereço de IP e obtenha geolocalização, provedor, ASN e dados de
            rede — direto da fonte, sem ruído.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button
              size="lg"
              nativeButton={false}
              render={<a href="#ferramenta" />}
              className="tracking-wider"
            >
              <ArrowDown className="size-4" aria-hidden="true" />
              Iniciar consulta
            </Button>
            <Button
              size="lg"
              variant="outline"
              nativeButton={false}
              render={<a href="#recursos" />}
              className="tracking-wider"
            >
              Ver recursos
            </Button>
          </div>

          <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="size-4 text-accent" aria-hidden="true" />
            Consultas processadas no servidor. Sem armazenamento de dados.
          </div>
        </div>

        {/* Janela de terminal decorativa */}
        <div className="rounded-md border border-border bg-card/80 shadow-2xl shadow-primary/5 backdrop-blur-sm">
          <div className="flex items-center gap-2 border-b border-border px-4 py-2.5">
            <span className="size-3 rounded-full bg-destructive/70" />
            <span className="size-3 rounded-full bg-chart-4/70" />
            <span className="size-3 rounded-full bg-primary/70" />
            <span className="ml-2 text-xs text-muted-foreground">
              root@node-osint: ~
            </span>
          </div>
          <div className="flicker space-y-2 p-4 text-sm leading-relaxed">
            <p className="text-muted-foreground">
              <span className="text-primary">$</span> node-osint lookup 8.8.8.8
            </p>
            <p className="text-foreground">
              <span className="text-accent">[+]</span> resolvendo alvo...
            </p>
            <p className="text-foreground">
              <span className="text-accent">[+]</span> país: Estados Unidos
              <span className="ml-1">US</span>
            </p>
            <p className="text-foreground">
              <span className="text-accent">[+]</span> provedor: Google LLC
            </p>
            <p className="text-foreground">
              <span className="text-accent">[+]</span> asn: AS15169
            </p>
            <p className="text-primary cursor-blink">
              <span>$</span>&nbsp;
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
