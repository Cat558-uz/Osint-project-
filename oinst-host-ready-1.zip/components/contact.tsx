import { Button } from '@/components/ui/button'
import { Mail, Code2, Send } from 'lucide-react'

export function Contact() {
  return (
    <section
      id="contato"
      className="scanlines relative overflow-hidden cyber-grid"
    >
      <div className="relative mx-auto max-w-3xl px-4 py-20 text-center md:px-6 md:py-28">
        <p className="mb-3 text-xs tracking-widest text-accent">// MÓDULO 03</p>
        <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground text-glow md:text-4xl">
          Vamos conversar
        </h2>
        <p className="mx-auto mt-4 max-w-md text-pretty leading-relaxed text-muted-foreground">
          Dúvidas, sugestões ou uma ideia de colaboração? Envie uma mensagem —
          normalmente respondo em até 48h.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Button
            size="lg"
            nativeButton={false}
            render={<a href="mailto:contato@node-osint.dev" />}
            className="tracking-wider"
          >
            <Send className="size-4" aria-hidden="true" />
            contato@node-osint.dev
          </Button>
          <Button
            size="lg"
            variant="outline"
            nativeButton={false}
            render={
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
              />
            }
            className="tracking-wider"
          >
            <Code2 className="size-4" aria-hidden="true" />
            GitHub
          </Button>
        </div>

        <div className="mx-auto mt-10 flex max-w-sm items-center justify-center gap-2 rounded-sm border border-border bg-card/60 px-4 py-3 text-xs text-muted-foreground">
          <Mail className="size-4 text-primary" aria-hidden="true" />
          <span className="cursor-blink">aguardando sua mensagem</span>
        </div>
      </div>
    </section>
  )
}
