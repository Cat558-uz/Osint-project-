'use client'

import { useState } from 'react'
import { IpLookup } from '@/components/ip-lookup'
import { Button } from '@/components/ui/button'
import { Check, CircleAlert, ExternalLink, Loader2, Mail, Phone, Search, ShieldCheck, UserRound, X } from 'lucide-react'

type Tab = 'ip' | 'email' | 'phone' | 'username'

const tabs: { id: Tab; label: string; icon: typeof Mail; description: string }[] = [
  { id: 'ip', label: 'IP / REDE', icon: ShieldCheck, description: 'Localização, ISP, ASN e risco' },
  { id: 'email', label: 'E-MAIL', icon: Mail, description: 'Validação e reputação' },
  { id: 'phone', label: 'TELEFONE', icon: Phone, description: 'Formato, país e operadora' },
  { id: 'username', label: 'USERNAME', icon: UserRound, description: 'Perfis públicos conhecidos' },
]

function ResultField({ label, value }: { label: string; value: unknown }) {
  return <div className="border-b border-border/60 py-2"><p className="text-[0.65rem] uppercase tracking-widest text-muted-foreground">{label}</p><p className="break-all text-sm text-foreground">{value === null || value === undefined || value === '' ? '—' : String(value)}</p></div>
}

function ApiCheck({ type }: { type: 'email' | 'phone' }) {
  const [value, setValue] = useState('')
  const [result, setResult] = useState<Record<string, any> | null>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const isEmail = type === 'email'

  async function submit(event: React.FormEvent) {
    event.preventDefault(); setLoading(true); setError(''); setResult(null)
    try {
      const response = await fetch('/api/check', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type, value }) })
      const data = await response.json()
      if (!response.ok || !data.success) throw new Error(data.message)
      setResult(data.data)
    } catch (err) { setError(err instanceof Error ? err.message : 'Erro ao consultar o provedor.') } finally { setLoading(false) }
  }

  return <div>
    <p className="mb-2 max-w-2xl leading-relaxed text-muted-foreground">{isEmail ? 'Valide sintaxe, entregabilidade, domínio, provedor e indicadores de endereço descartável.' : 'Normalize um número internacional e consulte país, tipo de linha, operadora e validade.'}</p>
    <p className="mb-5 border-l-2 border-accent/50 pl-3 text-xs leading-relaxed text-muted-foreground">Consulta feita por provedor externo autorizado. Não revela conteúdo de contas nem confirma a identidade de uma pessoa.</p>
    <form onSubmit={submit} className="flex flex-col gap-3 sm:flex-row">
      <input value={value} onChange={(e) => setValue(e.target.value)} required type={isEmail ? 'email' : 'tel'} placeholder={isEmail ? 'analista@exemplo.com' : '+55 11 99999-9999'} aria-label={isEmail ? 'Endereço de e-mail' : 'Número de telefone'} className="h-11 flex-1 rounded-sm border border-border bg-background px-3 text-sm outline-none focus:border-primary" />
      <Button type="submit" disabled={loading}>{loading ? <Loader2 className="size-4 animate-spin" /> : <Search className="size-4" />}{loading ? 'Consultando' : 'Executar check'}</Button>
    </form>
    {error && <div role="alert" className="mt-4 flex gap-2 border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive"><CircleAlert className="size-4 shrink-0" />{error}</div>}
    {result && <div className="mt-5 grid gap-x-8 sm:grid-cols-2 lg:grid-cols-3">{Object.entries(result).filter(([key]) => !['is_valid_format', 'is_free_email', 'is_disposable_email', 'is_valid'].includes(key)).slice(0, 12).map(([key, val]) => <ResultField key={key} label={key.replaceAll('_', ' ')} value={typeof val === 'object' ? JSON.stringify(val) : val} />)}</div>}
  </div>
}

function UsernameCheck() {
  const [username, setUsername] = useState('')
  const [results, setResults] = useState<{ name: string; url: string; status: string }[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  async function submit(event: React.FormEvent) {
    event.preventDefault(); setLoading(true); setError('')
    try { const response = await fetch(`/api/username?username=${encodeURIComponent(username)}`); const data = await response.json(); if (!response.ok) throw new Error(data.message); setResults(data.results) } catch (err) { setError(err instanceof Error ? err.message : 'Erro na consulta.') } finally { setLoading(false) }
  }
  return <div>
    <p className="mb-2 max-w-2xl leading-relaxed text-muted-foreground">Verifique a presença de um nome de usuário em plataformas públicas conhecidas. O resultado é indicativo e não confirma que os perfis pertencem à mesma pessoa.</p>
    <p className="mb-5 border-l-2 border-accent/50 pl-3 text-xs leading-relaxed text-muted-foreground">Somente URLs públicas são consultadas. Respeite os termos de cada plataforma e não use os resultados para assédio ou identificação indevida.</p>
    <form onSubmit={submit} className="flex flex-col gap-3 sm:flex-row"><div className="flex flex-1 items-center border border-border bg-background px-3"><span className="text-primary">@</span><input value={username} onChange={(e) => setUsername(e.target.value)} required placeholder="username" aria-label="Nome de usuário" className="h-11 w-full bg-transparent px-2 text-sm outline-none" /></div><Button type="submit" disabled={loading}>{loading ? <Loader2 className="size-4 animate-spin" /> : <Search className="size-4" />}{loading ? 'Verificando' : 'Pesquisar perfis'}</Button></form>
    {error && <div role="alert" className="mt-4 border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}
    {results.length > 0 && <div className="mt-5 grid gap-2 sm:grid-cols-2">{results.map((item) => <a key={item.name} href={item.url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between border border-border bg-background/50 p-3 transition-colors hover:border-primary/60"><span className="flex items-center gap-2 text-sm"><span className={item.status === 'encontrado' ? 'text-primary' : 'text-muted-foreground'}>{item.status === 'encontrado' ? <Check className="size-4" /> : <X className="size-4" />}</span>{item.name}</span><ExternalLink className="size-3.5 text-muted-foreground" /></a>)}</div>}
  </div>
}

export function OsintWorkbench() {
  const [active, setActive] = useState<Tab>('ip')
  return <section id="ferramenta" className="mx-auto max-w-6xl px-4 py-16 md:px-6 md:py-20"><div className="mb-8"><p className="mb-2 text-xs tracking-widest text-accent">// CENTRAL DE FERRAMENTAS</p><h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">Escolha um módulo de investigação</h2><p className="mt-2 max-w-2xl leading-relaxed text-muted-foreground">Checks estruturados para inteligência de fontes abertas, com transparência sobre limitações e origem dos dados.</p></div><div className="grid gap-6 lg:grid-cols-[230px_1fr]"><div role="tablist" aria-label="Ferramentas OSINT" className="flex gap-2 overflow-x-auto lg:flex-col">{tabs.map((tab) => { const Icon = tab.icon; return <button key={tab.id} role="tab" aria-selected={active === tab.id} onClick={() => setActive(tab.id)} className={`min-w-[145px] border p-3 text-left transition-colors lg:min-w-0 ${active === tab.id ? 'border-primary bg-primary/10 text-primary' : 'border-border bg-card/40 text-muted-foreground hover:border-primary/50'}`}><span className="flex items-center gap-2 text-xs font-bold tracking-wider"><Icon className="size-4" />{tab.label}</span><span className="mt-1 block text-[0.65rem] leading-relaxed opacity-70">{tab.description}</span></button> })}</div><div role="tabpanel" className="min-h-[330px] border border-border bg-card/50 p-4 sm:p-6">{active === 'ip' && <IpLookup />}{active === 'email' && <ApiCheck type="email" />}{active === 'phone' && <ApiCheck type="phone" />}{active === 'username' && <UsernameCheck />}</div></div></section>
}
