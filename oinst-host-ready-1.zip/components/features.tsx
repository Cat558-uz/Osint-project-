import { Gauge, Lock, MapPinned, ServerCog } from 'lucide-react'

const features = [
  {
    icon: MapPinned,
    title: 'Geolocalização precisa',
    desc: 'País, região, cidade, CEP e coordenadas de qualquer IP público.',
  },
  {
    icon: ServerCog,
    title: 'Dados de ASN & ISP',
    desc: 'Identifique o provedor, a organização e o número de sistema autônomo.',
  },
  {
    icon: Gauge,
    title: 'Respostas em tempo real',
    desc: 'Consultas processadas no servidor com resposta imediata, sem filas.',
  },
  {
    icon: Lock,
    title: 'Privacidade por padrão',
    desc: 'Nenhuma consulta é registrada ou armazenada. Zero rastreamento.',
  },
]

export function Features() {
  return (
    <section
      id="recursos"
      className="border-y border-border bg-card/30"
    >
      <div className="mx-auto max-w-6xl px-4 py-16 md:px-6 md:py-20">
        <div className="mb-10">
          <p className="mb-2 text-xs tracking-widest text-accent">
            // MÓDULO 02
          </p>
          <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
            Recursos
          </h2>
        </div>

        <div className="grid gap-px overflow-hidden rounded-md border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div
              key={f.title}
              className="group bg-card p-6 transition-colors hover:bg-secondary/40"
            >
              <f.icon
                className="mb-4 size-6 text-primary transition-transform group-hover:scale-110"
                aria-hidden="true"
              />
              <h3 className="mb-1.5 text-sm font-bold tracking-wider text-foreground">
                {f.title}
              </h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
