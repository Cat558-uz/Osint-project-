import { Terminal } from 'lucide-react'

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-muted-foreground md:flex-row md:px-6">
        <div className="flex items-center gap-2">
          <Terminal className="size-4 text-primary" aria-hidden="true" />
          <span className="tracking-widest text-foreground">
            NODE<span className="text-accent">//</span>OSINT
          </span>
        </div>
        <p className="tracking-wider">
          {`> feito para pesquisa e uso ético · ${new Date().getFullYear()}`}
        </p>
      </div>
    </footer>
  )
}
